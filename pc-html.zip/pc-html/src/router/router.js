import defaultRouter from "./defaultRouter";
export default defaultRouter.getDefaultRouterList()
