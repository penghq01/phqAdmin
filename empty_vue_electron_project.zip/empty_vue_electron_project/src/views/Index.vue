<template>
  <div>
    index
  </div>
</template>

<script>
  export default {
    name: 'Index',
    data () {
      return {}
    },
    mounted(){

    },
    methods: {}
  }
</script>

<style scoped lang="scss">

</style>
