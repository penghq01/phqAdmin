<template>
    <div class="login">
       登录
    </div>
</template>
<script>

    export default {
        name: 'login',
        data() {
            return {

            }
        },
        methods: {

        }
    }
</script>
<style scoped>

</style>
